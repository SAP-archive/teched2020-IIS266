﻿## Chapter 6 \- Task Assignment 

In this Chapter you know how can you assign tasks to yourself



### Step 1: Home - Google Chrome



\(1\) Click  **Overview** .

![](Markdown_files/img_0.png)



### Step 2: Overview - Google Chrome



\(1\) Note that you have no assigned tasks. Click ![](Markdown_files/fieldicon_153.png)to navigate to Task list and assign some tasks.

![](Markdown_files/img_000.png)



### Step 3: Tasks - Google Chrome



\(1\) Click  ![](Markdown_files/fieldicon.png) to remove the active filter and see all tasks.

![](Markdown_files/img_001.png)



### Step 4: Tasks - Google Chrome



\(1\) Click  ![](Markdown_files/fieldicon00.png).

![](Markdown_files/img_002.png)



### Step 5: Tasks - Google Chrome



\(1\) Click  ![](Markdown_files/fieldicon_168.png).

![](Markdown_files/img_003.png)



### Step 6: Tasks - Google Chrome



\(1\) Click  ![](Markdown_files/fieldicon_174.png) to select all tasks.

![](Markdown_files/img_004.png)



### Step 7: Tasks - Google Chrome



\(1\) Click  ![](Markdown_files/fieldicon01.png) to launch mass editing.

![](Markdown_files/img_005.png)



### Step 8: Tasks - Google Chrome



\(1\) Click  ![](Markdown_files/fieldicon02.png).

![](Markdown_files/img_006.png)



### Step 9: Tasks - Google Chrome



\(1\) Click  ![](Markdown_files/fieldicon03.png).

![](Markdown_files/img_007.png)



### Step 10: Tasks - Google Chrome



\(1\) Search for your user name by entering teched\-build xx where xx is your user name

![](Markdown_files/img_008.png)



### Step 11: Tasks - Google Chrome



\(1\) Click  ![](Markdown_files/fieldicon04.png).

![](Markdown_files/img_009.png)



### Step 12: Tasks - Google Chrome



\(1\) Click  ![](Markdown_files/fieldicon05.png).

![](Markdown_files/img_010.png)



### Step 13: Tasks - Google Chrome



\(1\) Notice that the assignee column shows your user name. Click  ![](Markdown_files/fieldicon06.png) to go back to Overview\.\.

![](Markdown_files/img_011.png)



### Step 14: Overview - Google Chrome



![](Markdown_files/info_word.png)

Note the number of tasks assigned to you has changed.

 

You have completed this Chapter.



 

![](Markdown_files/img_012.png)



