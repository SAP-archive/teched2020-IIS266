﻿## Chapter 2 \- Create Scope

### Step 1: Home - Google Chrome



\(1\) Click to navigate to  **Overview.** 

![](Markdown_files/img_0.png)



### Step 2: Overview - Google Chrome



\(1\) Click  ![](Markdown_files/fieldicon_8.png).

![](Markdown_files/img_000.png)



### Step 3: Tasks - Google Chrome



\(1\) Click  ![](Markdown_files/fieldicon.png) to forward navigate to desired application.

![](Markdown_files/img_001.png)



### Step 4: Processes - Google Chrome



\(1\) Click  **Edit** .

![](Markdown_files/img_002.png)



### Step 5: Processes - Google Chrome



\(1\) Click  **Manage Scopes** .

![](Markdown_files/img_003.png)



### Step 6: Processes - Google Chrome



\(1\) Click  **Add** .

![](Markdown_files/img_004.png)



### Step 7: Processes - Google Chrome



\(1\) Enter  **Sales and Customer Returns A/B xx**  in the  **Scope**  text field.

![](Markdown_files/img_005.png)



### Step 8: Processes - Google Chrome



\(1\) Click  **Save** .

![](Markdown_files/img_006.png)



### Step 9: Processes - Google Chrome



\(1\) Click  ![](Markdown_files/fieldicon00.png) to select the appropriate content package which is S4 HANA Cloud in this case 

![](Markdown_files/img_007.png)



### Step 10: Processes - Google Chrome



\(1\) Click  ![](Markdown_files/fieldicon_62.png).

![](Markdown_files/img_008.png)



### Step 11: Processes - Google Chrome



\(1\) Click  ![](Markdown_files/fieldicon01.png).

![](Markdown_files/img_009.png)



### Step 12: Processes - Google Chrome



\(1\) Click  ![](Markdown_files/fieldicon_68.png) to get country specific content for Fit to Standard workshops.

![](Markdown_files/img_010.png)



### Step 13: Processes - Google Chrome



\(1\) Click  ![](Markdown_files/fieldicon_106.png) to put the desired process\(BKP\) in scope.

![](Markdown_files/img_011.png)



### Step 14: Processes - Google Chrome



\(1\) Click  ![](Markdown_files/fieldicon_108.png)to add another process  **1Z3** in scope.

![](Markdown_files/img_012.png)



### Step 15: Processes - Google Chrome



\(1\) Click  **Done to**  save the scope. You have completed the Chapter.

![](Markdown_files/img_013.png)



